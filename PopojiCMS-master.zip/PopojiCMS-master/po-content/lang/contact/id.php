<?php
/**
 *
 * - PopojiCMS Contact Language
 *
 * - File : id.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
*/

$_['component_name'] = 'Kontak';
$_['contact_name'] = 'Nama';
$_['contact_email'] = 'Email';
$_['contact_subject'] = 'Subjek';
$_['contact_message'] = 'Pesan';
$_['contact_action'] = 'Tindakan';
$_['contact_read'] = 'Tandai Sudah di Baca';
$_['contact_notread'] = 'Tandai Belum di Baca';
$_['contact_view'] = 'Lihat';
$_['contact_reply'] = 'Balas';
$_['contact_dialog_title_1'] = 'Detail';
$_['contact_dialog_title_2'] = 'Balas';
$_['contact_message_1'] = 'Balasan kontak telah berhasil dikirim';
$_['contact_message_2'] = 'Kontak telah berhasil dihapus';
$_['contact_message_3'] = 'Kesalahan mengirimkan balasan kontak';
$_['contact_message_4'] = 'Kesalahan menghapus data kontak';
